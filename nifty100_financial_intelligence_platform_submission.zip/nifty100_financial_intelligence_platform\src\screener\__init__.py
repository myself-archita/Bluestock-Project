"""Screener helpers."""
