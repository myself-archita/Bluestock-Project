"""Analytics helpers."""
